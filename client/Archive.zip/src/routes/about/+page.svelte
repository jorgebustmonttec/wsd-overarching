<svelte:head>
  <title>About</title>
</svelte:head>

<p>This is my about page!</p>