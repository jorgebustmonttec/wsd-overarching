<script>
  // No additional logic
</script>

<div class="p-6 bg-blue-100 rounded-lg shadow-md">
  <h1 class="text-4xl text-blue-600">Test Page</h1>
  <button class="btn preset-filled-primary-500">Click Me</button>
</div>
