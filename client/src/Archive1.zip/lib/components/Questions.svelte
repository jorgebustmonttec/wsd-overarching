<script>
    import QuestionForm  from "./QuestionForm.svelte";
    import QuestionList  from "./QuestionList.svelte";
  </script>
  
  <h1>Ask &amp; Vote Questions</h1>
  
  <QuestionForm  />
  <hr />
  <QuestionList />
  