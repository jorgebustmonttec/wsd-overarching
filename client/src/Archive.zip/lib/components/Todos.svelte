<script>
  import TodoForm from "./TodoForm.svelte";
  import TodoList from "./TodoList.svelte";
</script>

<section class="p-6">
  <h1 class="text-4xl font-bold mb-6 text-center">📝 Todos</h1>
  <TodoForm />
  <TodoList />
</section>
