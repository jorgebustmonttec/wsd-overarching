export const load = async ({ locals }) => {
  return locals;
};