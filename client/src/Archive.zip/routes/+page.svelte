<script>
    import Questions from "$lib/components/question/Questions.svelte";
  </script>

  <h1>Welcome!</h1>