
  <div class="space-y-6">
    <div class="bg-blue-100 p-6 rounded-lg shadow-md">
      <h1>Welcome!</h1>
    </div>
  </div>