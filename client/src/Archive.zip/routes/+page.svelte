<script>
    import Message from "$lib/components/Message.svelte";
</script>

<p>Hello World!</p>
