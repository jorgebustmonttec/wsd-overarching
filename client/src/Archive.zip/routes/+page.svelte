<script>
  import Todos from "$lib/components/Todos.svelte";
</script>

<Todos />
