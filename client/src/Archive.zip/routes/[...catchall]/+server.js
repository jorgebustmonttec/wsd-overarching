export function GET() {
  return new Response("Not Found", { status: 404 });
}
