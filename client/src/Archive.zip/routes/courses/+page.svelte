<script>
  import CourseForm from "$lib/components/course/CourseForm.svelte";
  import CourseList from "$lib/components/course/CourseList.svelte";
</script>

<h1>Courses</h1>


<CourseList />
<CourseForm />
